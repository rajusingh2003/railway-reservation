# Railway Reservation System

Full stack PHP + MySQL based ticket booking system.

- User Register/Login
- Book Ticket
- Check PNR Status
- Admin Panel